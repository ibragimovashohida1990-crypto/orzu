# 🛍️ Orzu — onlayn do'kon

React + Supabase asosidagi bitta fayldan iborat onlayn do'kon sayti.

## Imkoniyatlar
- Mahsulotlar katalogi, qidiruv, kategoriyalar, savat va buyurtma
- Ro'yxatdan o'tish / kirish (Supabase Auth), shaxsiy kabinet
- Admin panel (mahsulot, kategoriya va buyurtmalarni boshqarish)
- Faqat haqiqiy xaridorlar yoza oladigan sharh va reytinglar (rasm bilan)
- AI yordamchi (Supabase Edge Function + Groq / Gemini)

## Tuzilma
```
index.html                              → butun sayt
supabase/sql/supabase_setup.sql         → profillar, rollar, xavfsizlik
supabase/sql/supabase_reviews.sql       → sharh va reyting jadvali
supabase/functions/ai-assistant/        → AI yordamchi funksiyasi
```

## Ishga tushirish
1. Supabase da loyiha yarating va `supabase/sql` dagi fayllarni SQL Editor da ishga tushiring.
2. `index.html` ichidagi Supabase URL va publishable kalitni o'zingiznikiga almashtiring.
3. AI uchun Edge Function ni deploy qiling va Secrets ga `GROQ_API_KEY`, `GEMINI_API_KEY` ni qo'shing.
4. Saytni GitHub Pages orqali joylang.

> ⚠️ `service_role` kalitini, Groq va Gemini kalitlarini hech qachon GitHub ga yuklamang. Ular faqat Supabase Secrets da turadi.

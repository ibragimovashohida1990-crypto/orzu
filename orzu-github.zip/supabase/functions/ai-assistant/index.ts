// Supabase Edge Function: ai-assistant
// Mijoz savolini + katalogni AI ga yuboradi. Bir necha bepul provayder zanjiri:
// 1) Groq (GROQ_API_KEY)  2) Gemini (GEMINI_API_KEY). Biri band yoki xato bersa, keyingisiga o'tadi.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// Model nomlari tez-tez almashadi: groq.com/docs/models va ai.google.dev/gemini-api/docs/models
const GROQ_MODELS = ["openai/gpt-oss-120b", "openai/gpt-oss-20b"];
const GEMINI_MODELS = ["gemini-3.8-flash", "gemini-3.7-flash", "gemini-3.5-flash-lite"];

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
const money = (n: number) => String(Math.round(Number(n))).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
const sleep = (ms: number) => new Promise((ok) => setTimeout(ok, ms));

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const { question, history = [] } = await req.json();
    const q = String(question || "").trim().slice(0, 500);
    if (!q) return json({ message: "Savolingizni yozing." });

    // 1) Katalog (Groq bepul rejasida daqiqasiga 8000 token chegarasi bor, shuning uchun ixcham)
    const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: rows, error } = await db.from("products")
      .select("id,name,price,old_price,short_description,rating,stock,image_url,categories(name)")
      .gt("stock", 0).limit(40);
    if (error) throw error;
    const catalog = (rows || []).map((p: any) =>
      `#${p.id} | ${p.name} | ${p.categories?.name} | ${money(p.price)} so'm${p.old_price ? ` (eski narx ${money(p.old_price)})` : ""} | ${p.rating ?? "-"}★ | ${String(p.short_description ?? "").slice(0, 80)}`).join("\n");

    const system = `Sen "Orzu" onlayn do'konining AI yordamchisisan.
QOIDALAR:
1. Faqat o'zbek tilida (lotin yozuvi) yoz: sodda, imlosi to'g'ri, tabiiy jumlalar bilan. Rus yoki ingliz so'zlarini aralashtirma (mahsulot nomlari bundan mustasno).
2. Mahsulot nomi, narxi, chegirmasi va omborini FAQAT quyidagi katalogdan ol. Hech narsani o'ylab topma, narxni taxmin qilma. Narxni katalogdagidek yoz (masalan: 1 250 000 so'm).
3. Mos mahsulot katalogda bo'lmasa, ochiq ayt ("Hozircha bunday mahsulot yo'q") va eng yaqin variantni taklif qil.
4. Yetkazib berish muddati, kafolat, to'lov va qaytarish shartlari katalogda yo'q. Bilmasang, o'ylab topma: "Buni do'kon administratoridan aniqlang" de.
5. Salomlashish va umumiy savollarga qisqa, samimiy javob ber, so'ng nima izlayotganini so'ra.
6. Javob 2–5 jumla bo'lsin. Tavsiya qilgan mahsulotlaringni nomi va narxi bilan message ichida yoz, id larini product_ids ga qo'y (ko'pi bilan 3 ta).
7. Byudjet aytilsa, undan oshmaydigan mahsulotlarni tanla. Oldingi suhbatni hisobga ol.
8. Javobing uzun ro'yxat bo'lmasin. Muhim so'zni **qalin** qilib ajratish mumkin.
FORMAT: faqat JSON: {"message":"matn","product_ids":[raqamlar]}
KATALOG:
${catalog}`;

    // 2) Suhbat tarixi: user bilan boshlansin, rollar navbatma-navbat kelsin
    const msgs: { role: string; content: string }[] = [];
    for (const h of [...history].slice(-6)) {
      const role = h.role === "user" ? "user" : "assistant";
      const content = String(h.text || "").slice(0, 500);
      if (!content || (!msgs.length && role !== "user")) continue;
      if (msgs.length && msgs[msgs.length - 1].role === role) msgs[msgs.length - 1].content += "\n" + content;
      else msgs.push({ role, content });
    }
    if (msgs.length && msgs[msgs.length - 1].role === "user") msgs[msgs.length - 1].content += "\n" + q;
    else msgs.push({ role: "user", content: q });

    // 3) Provayderlar zanjiri (kalitlar faqat serverda turadi)
    type Attempt = { label: string; call: () => Promise<Response>; pick: (d: any) => string };
    const groqA: Attempt[] = [], gemA: Attempt[] = [], attempts: Attempt[] = [];
    const groqKey = Deno.env.get("GROQ_API_KEY");
    if (groqKey) for (const model of GROQ_MODELS) groqA.push({
      label: `groq/${model}`,
      call: () => fetch("https://api.groq.com/openai/v1/chat/completions", {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${groqKey}` },
        body: JSON.stringify({ model, messages: [{ role: "system", content: system }, ...msgs],
          response_format: { type: "json_object" }, reasoning_effort: "medium", max_completion_tokens: 1500, temperature: 0.3 }),
      }),
      pick: (d) => d.choices?.[0]?.message?.content || "",
    });
    const gemKey = Deno.env.get("GEMINI_API_KEY");
    if (gemKey) for (const model of GEMINI_MODELS) gemA.push({
      label: `gemini/${model}`,
      call: () => fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
        method: "POST",
        headers: { "content-type": "application/json", "x-goog-api-key": gemKey },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: system }] },
          contents: msgs.map((m) => ({ role: m.role === "user" ? "user" : "model", parts: [{ text: m.content }] })),
          generationConfig: { responseMimeType: "application/json", maxOutputTokens: 2048, temperature: 0.3 },
        }),
      }),
      pick: (d) => d.candidates?.[0]?.content?.parts?.map((x: any) => x.text || "").join("") || "",
    });

    // Tartib: AI_ORDER secret ("gemini,groq" yoki "groq,gemini"). O'zbekcha sifati yaxshisi birinchi tursin
    const order = (Deno.env.get("AI_ORDER") || "groq,gemini").split(",").map((x) => x.trim());
    for (const n of order) attempts.push(...(n === "gemini" ? gemA : n === "groq" ? groqA : []));
    let text = "";
    for (const a of attempts) {
      try {
        const r = await a.call();
        const d = await r.json();
        if (r.ok && a.pick(d)) { text = a.pick(d); break; }
        console.error(`Xato (${a.label}) [${r.status}]:`, JSON.stringify(d).slice(0, 400));
        if (r.status === 429 || r.status >= 500) await sleep(500);
      } catch (e) { console.error(`Xato (${a.label}):`, e); }
    }
    if (!text) return json({ message: "AI hozir band. Bir daqiqadan keyin qayta urinib ko'ring." });

    // 4) JSON ni ajratib, id larni katalogga solishtiramiz (o'ylab topilgan id o'tmaydi)
    let out = { message: text, product_ids: [] as number[] };
    try { out = JSON.parse(text.match(/\{[\s\S]*\}/)![0]); } catch (_) { /* oddiy matn qaytsa ham bo'ladi */ }
    const byId = new Map((rows || []).map((p: any) => [p.id, p]));
    const products = (out.product_ids || []).map((id) => byId.get(Number(id))).filter(Boolean).slice(0, 3)
      .map((p: any) => ({ id: p.id, name: p.name, price: p.price, image_url: p.image_url, categories: p.categories }));
    return json({ message: out.message || text, products });
  } catch (e) {
    console.error(e);
    return json({ message: "Xatolik yuz berdi. Keyinroq urinib ko'ring." }, 500);
  }
});

-- Supabase > SQL Editor. Sharh va reytinglar uchun. Qayta ishga tushirsa ham xavfsiz.
-- DIQQAT: orders jadvalida foydalanuvchi ustuni "user_id", order_items da mahsulot ustuni "product_id" deb faraz qilindi.
-- Ular boshqacha bo'lsa, quyidagi has_purchased funksiyasida nomlarni almashtiring.

-- 1) Sharhlar jadvali (bitta xaridor bitta mahsulotga bitta sharh)
create table if not exists public.reviews (
  id bigint generated always as identity primary key,
  product_id bigint not null references public.products(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  author_name text,
  rating int not null check (rating between 1 and 5),
  comment text check (char_length(comment) <= 1000),
  image_url text,
  created_at timestamptz not null default now(),
  unique (product_id, user_id)
);

-- 2) Haqiqiy xaridorni tekshirish: shu mahsulotni (bekor qilinmagan) buyurtma qilganmi
create or replace function public.has_purchased(p_product bigint) returns boolean
language sql security definer set search_path = public stable as $$
  select exists (
    select 1 from public.order_items oi join public.orders o on o.id = oi.order_id
    where oi.product_id = p_product and o.user_id = auth.uid() and o.status <> 'cancelled');
$$;
grant execute on function public.has_purchased(bigint) to authenticated;

-- 3) Xavfsizlik (RLS): hamma o'qiydi, faqat haqiqiy xaridor yozadi
alter table public.reviews enable row level security;
drop policy if exists reviews_read on public.reviews;
drop policy if exists reviews_insert on public.reviews;
drop policy if exists reviews_update on public.reviews;
drop policy if exists reviews_delete on public.reviews;
create policy reviews_read on public.reviews for select using (true);
create policy reviews_insert on public.reviews for insert to authenticated
  with check (user_id = auth.uid() and public.has_purchased(product_id));
create policy reviews_update on public.reviews for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid() and public.has_purchased(product_id));
create policy reviews_delete on public.reviews for delete to authenticated
  using (user_id = auth.uid() or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin'));

-- 4) Ism serverda qo'yiladi (soxtalashtirib bo'lmaydi), asosiy maydonlar o'zgarmaydi
create or replace function public.reviews_before() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    new.author_name := coalesce(nullif((select full_name from public.profiles where id = new.user_id), ''), 'Xaridor');
  else
    new.author_name := old.author_name; new.product_id := old.product_id; new.user_id := old.user_id;
  end if;
  new.comment := nullif(trim(coalesce(new.comment, '')), '');
  return new;
end $$;
drop trigger if exists reviews_before_trg on public.reviews;
create trigger reviews_before_trg before insert or update on public.reviews
  for each row execute function public.reviews_before();

-- 4.5) products jadvalidagi eski cheklov reytingga 0 ni taqiqlaydi. "Baho yo'q" = 0 bo'lishi uchun uni yangilaymiz
alter table public.products drop constraint if exists products_rating_check;
alter table public.products add constraint products_rating_check check (rating is null or (rating >= 0 and rating <= 5));

-- 5) Mahsulotning reytingi va sharhlar soni avtomatik hisoblanadi
create or replace function public.reviews_refresh() returns trigger
language plpgsql security definer set search_path = public as $$
declare pid bigint := coalesce(new.product_id, old.product_id);
begin
  update public.products set
    rating = coalesce((select round(avg(rating)::numeric, 1) from public.reviews where product_id = pid), 0),
    review_count = (select count(*) from public.reviews where product_id = pid)
  where id = pid;
  return null;
end $$;
drop trigger if exists reviews_refresh_trg on public.reviews;
create trigger reviews_refresh_trg after insert or update or delete on public.reviews
  for each row execute function public.reviews_refresh();

-- 6) Faqat real baholar: sharhi yo'q mahsulotlardagi eski (namuna) reytinglarni tozalaydi
update public.products p set rating = 0, review_count = 0
where not exists (select 1 from public.reviews r where r.product_id = p.id);

-- 7) Sharh rasmlari uchun ochiq bucket (har kim faqat o'z papkasiga yuklaydi)
insert into storage.buckets (id, name, public) values ('review-images', 'review-images', true) on conflict (id) do nothing;
drop policy if exists review_img_read on storage.objects;
drop policy if exists review_img_write on storage.objects;
create policy review_img_read on storage.objects for select using (bucket_id = 'review-images');
create policy review_img_write on storage.objects for insert to authenticated
  with check (bucket_id = 'review-images' and (storage.foldername(name))[1] = auth.uid()::text);

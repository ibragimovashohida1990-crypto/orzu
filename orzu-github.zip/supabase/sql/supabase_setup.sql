-- Supabase > SQL Editor ga qo'yib, Run bosing. Qayta ishga tushirsa ham xavfsiz.

-- 1) profiles jadvaliga yetishmayotgan ustunlar
alter table public.profiles add column if not exists address text;
alter table public.profiles add column if not exists phone text;

-- 2) Ro'yxatdan o'tganda profil avtomatik yaratilsin (ism va telefon signUp dan olinadi)
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, phone)
  values (new.id, new.raw_user_meta_data->>'full_name', nullif(new.raw_user_meta_data->>'phone',''))
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- 3) Eski foydalanuvchilar uchun profil qatori bo'lmasa, yaratib qo'yamiz
insert into public.profiles (id) select id from auth.users on conflict (id) do nothing;

-- 4) XAVFSIZLIK: oddiy foydalanuvchi o'z rolini admin qila olmasin
create or replace function public.protect_role() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.role is distinct from old.role and auth.uid() is not null
     and not exists (select 1 from public.profiles where id = auth.uid() and role = 'admin') then
    new.role := old.role;
  end if;
  return new;
end $$;
drop trigger if exists protect_role_trg on public.profiles;
create trigger protect_role_trg before update on public.profiles
  for each row execute function public.protect_role();

-- 5) O'zingizni admin qiling (emailni almashtiring!)
update public.profiles set role = 'admin'
where id = (select id from auth.users where email = 'SIZNING_EMAILINGIZ@gmail.com');
